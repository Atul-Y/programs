// 1. if inner loop is dependent of the outer loop for eg  inner loop is for(j=i;codi;j++) ; then is 100% can be solved by stack in improved version

