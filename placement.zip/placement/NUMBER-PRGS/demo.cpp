#include <iostream>
#include <bits/stdc++.h>

using namespace std;
int main()
{
    cout<<"HELLO WORLD";
    return 0;
}