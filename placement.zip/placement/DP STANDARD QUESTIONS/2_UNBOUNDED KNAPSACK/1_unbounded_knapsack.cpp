#include <iostream>
#include <vector>

using namespace std;

void unboundedKnapsack(int n, vector<int> val, vector<int> weight, int cap) {
    
  vector<int> dp(cap + 1);    //SOLUTION USING ONLY 1D MATRIX
  dp[0] = 0;

  for (int c = 1; c <= cap; c++) {
    int mx = 0;
    for (int i = 0; i < n; i++) {
      if (weight[i] <= c) {
        int rembagc = c - weight[i];
        int rembagv = dp[rembagc];
        int tbagv = rembagv + val[i];

        if (tbagv > mx) {
          mx = tbagv;
        }

      }
    }
    dp[c] = mx;

  }
  cout << dp[cap];

}


int main() {

  int n;
  cin >> n;
  vector<int> val(n);
  for (int i = 0; i < n; i++) {

    cin >> val[i];
  }
  vector<int> weight(n);
  for (int i = 0; i < n; i++) {
    cin >> weight[i];
  }
  int cap;
  cin >> cap;

  unboundedKnapsack(n, val, weight, cap);


}



//ADITYA VERMA CODE----------------------------------------------------------------

#include <bits/stdc++.h>     //SOLUTION USING 2D MATRIX
using namespace std;

int Un_knapsack(int wt[], int val[], int W, int n) {
	int t[n + 1][W + 1]; // DP matrix

	for (int i = 0; i <= n; i++) {
		for (int j = 0; j <= W; j++) {
			if (i == 0 || j == 0) // base case
				t[i][j] = 0;
			else if (wt[i - 1] <= j) { // current wt can fit in bag
				int val1 = val[i - 1] + t[i][j - wt[i - 1]]; // take current wt
				int val2 = t[i - 1][j]; // skip current wt
				t[i][j] = max(val1, val2);
			}
			else if (wt[i - 1] > j) // current wt doesn't fit in bag
				t[i][j] = t[i - 1][j];
		}
	}

	return t[n][W];
}

signed main() {
	int n; cin >> n; // number of items
	int val[n], wt[n]; // values and wts array
	for (int i = 0; i < n; i++)
		cin >> wt[i];
	for (int i = 0; i < n; i++)
		cin >> val[i];
	int W; cin >> W; // capacity

	cout << Un_knapsack(wt, val, W, n) << endl;
	return 0;
}