#include <iostream>
#include <bits/stdc++.h>
using namespace std;

// int main()
// {
//     string s="111";
//     int num=stoi(s);
//     cout<<num;
//     return 0;
// }

int main()
{
        int num=111;
        string s=to_string(num);
        cout<<s; // converts integer to string
        int n=stoi(s); // converts string to integer
        return 0;
}
